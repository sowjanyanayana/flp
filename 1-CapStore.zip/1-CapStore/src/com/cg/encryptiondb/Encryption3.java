package com.cg.encryptiondb;

import java.util.Scanner;

public class Encryption3 {

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {

		Dao dao = new Dao();
		Bean bean=new Bean();
		System.out.println("enter your username");
		String username = scanner.nextLine();
		bean.setUsername(username);
		
		System.out.println("enter your password");
		String password = scanner.next();
		bean.setPassword(password);
		//ENCRYPTION
		if (password.matches("[A-Za-z0-9!@#$%^&*()_+]{8,12}")) {
			String s=dao.save(bean);
			if(s!= null){
				System.out.println("hexvalue: "+s);
			}
			else{
				System.out.println("not saved");
			}
		}
		else
		{
			System.out.println("password pattern not matched");
		}
		
		
		//DECRYPTION
		
		System.out.println("enter your username");
		String username1 = scanner.next();
		bean.setUsername(username1);
		
		System.out.println("enter your password");
		String password1 = scanner.next();
		bean.setPassword(password1);
		
		
		if (password1.matches("[A-Za-z0-9!@#$%^&*()_+]{8,12}")) {
			String s1=dao.search(bean);
			if(s1!= null){
				System.out.println("password: "+s1);
			}
			else{
				System.out.println("not valid user");
			}
		}
		else
		{
			System.out.println("enter correct password");
		}
		
	}
}
