package com.cg.encryptiondb;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class Dao {
	static StringBuffer buffer = new StringBuffer();
	static StringBuffer buffer2 = new StringBuffer();
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();

	public String save(Bean bean) {
		StringBuffer sb = null;

		char[] ch = bean.getPassword().toCharArray();
		for (char c : ch) {
			String s = Integer.toHexString((int) c + 50);
			sb = buffer.append(s.toUpperCase());
		}

		bean.setPassword(sb.toString());
		em.getTransaction().begin();
		em.persist(bean);
		em.getTransaction().commit();
		System.out.println(bean.toString());

		return sb.toString();
	}

	public String search(Bean bean) {

		String string = bean.getUsername();
		Query q= (Query) em.createQuery("select b.username from Bean b");
		List<String> list=q.getResultList();
		for (String string2 : list) {
		if (string2.equals(string)) {
			Query query = em.createQuery("select b.password from Bean b where username=:un");
			query.setParameter("un",string);
			String s1 = (String) query.getSingleResult();
			int length = s1.toString().toLowerCase().length();
			for (int i = 0; i < length - 1; i += 2) {

				String j = s1.substring(i, (i + 2));
				int d1 = Integer.parseInt(j, 16);
				buffer2.append((char) (d1 - 50));

			}
		}}
		return buffer2.toString();
	}

}
