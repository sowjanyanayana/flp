package com.cg.encryption;

public class Encryption {
	public static void main(String[] args) {
		
		String string = "fgdfg@123";
		int len=string.length();
		String s1=string.concat("ABCD");
		char[] c = s1.toCharArray();
		
		StringBuffer buffer = new StringBuffer();
		
		StringBuffer buffer1 = new StringBuffer();
		StringBuffer s=null;
		
		//ENCRYPTION
		for (char d : c) {

			buffer.append(Integer.toHexString(d));
		}
		System.out.println("hex:" + buffer.toString());

		//DECRYPTION
		String hex = "66676466674031323341424344";
		for (int i = 0; i < hex.length() - 1; i += 2) {

			String j = hex.substring(i, (i + 2));
			int d1 = Integer.parseInt(j, 16);
			s = buffer1.append((char) d1);
						
		}
		System.out.println(s.toString());

		System.out.println("string:" + buffer1.toString());
		
		
		String original=buffer1.toString();
		
		System.out.println(original.substring(0, len));
	}
}
