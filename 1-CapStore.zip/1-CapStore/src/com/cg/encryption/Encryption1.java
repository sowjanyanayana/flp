package com.cg.encryption;

public class Encryption1 {

	public static void main(String[] args) {
		//ENCRYPTION
		String s="Sowjanya@123";
		char[] c=s.toCharArray();
		StringBuffer buffer=new StringBuffer();
		for (char d : c) {
			
			int c1=(int)d;
			buffer.append(Integer.toHexString(c1+1));
			//buffer.append(c1+1);
		}
		System.out.println("hex value="+buffer.toString());
		
		//DECRYPTION
		StringBuffer buffer2=new StringBuffer();
		String s1="5470786b626f7a6241323334";
		for (int i = 0; i < s1.length() - 1; i += 2) {

			String j = s1.substring(i, (i + 2));
			int d1 = Integer.parseInt(j, 16);
			buffer2.append((char)(d1-1));
						
		}
		System.out.println("string for hex="+buffer2.toString());
	}

}
//5470786b626f7a6241323334
//84112120107981111229865505152
